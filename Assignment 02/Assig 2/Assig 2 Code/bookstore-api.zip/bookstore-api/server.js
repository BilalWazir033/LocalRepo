const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const bookRoutes = require('./routes/books');
const logger = require('./middleware/logger');

dotenv.config();
const app = express();

// Middleware
app.use(express.json());
app.use(logger);

// Routes
app.use('/api/books', bookRoutes);

// Connect DB
connectDB();

// 404 Handler (Invalid Route)
app.use((req, res, next) => {
  const error = new Error("Route not found");
  error.status = 404;
  next(error);
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error(`[ERROR] ${err.message}`);
  res.status(err.status || 500).json({
    success: false,
    error: err.message || "Server Error"
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
