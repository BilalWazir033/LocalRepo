// middleware/logger.js
function logger(req, res, next) {
  const now = new Date().toISOString();   // ✅ current date & time
  console.log(`[${now}] ${req.method} ${req.url}`);
  next();
}

module.exports = logger;
