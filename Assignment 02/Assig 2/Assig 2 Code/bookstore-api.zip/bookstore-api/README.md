# Online Bookstore Management API

## 📌 Overview
A RESTful API built with **Node.js**, **Express**, and **MongoDB** to manage books in an online bookstore.

---

## 📌 Features
- CRUD operations (Create, Read, Update, Delete)
- Search by author and genre
- Pagination for large book lists
- Middleware for logging requests
- Error handling with JSON responses

---

## 📌 Dependencies
- express
- mongoose
- dotenv
- body-parser
- nodemon (for development)

---

## 📌 Setup
1. Clone the repository or create the project folder.
2. Run:
   ```bash
   npm install
