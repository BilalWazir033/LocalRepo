const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// ✅ GET all books (with search + pagination)
router.get('/', async (req, res) => {
  try {
    const { author, genre, page = 1, limit = 5 } = req.query;
    let query = {};

    if (author) query.author = new RegExp(author, 'i'); // case-insensitive search
    if (genre) query.genre = new RegExp(genre, 'i');

    const books = await Book.find(query)
      .limit(parseInt(limit))
      .skip((page - 1) * parseInt(limit))
      .exec();

    const count = await Book.countDocuments(query);

    res.status(200).json({
      total: count,
      page: parseInt(page),
      limit: parseInt(limit),
      books
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ✅ GET single book by ID
router.get('/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ error: "Book not found" });
    res.status(200).json(book);
  } catch (err) {
    res.status(400).json({ error: "Invalid ID" });
  }
});

// ✅ POST add new book
router.post('/', async (req, res) => {
  try {
    const { title, author, price } = req.body;
    if (!title || !author || !price) {
      return res.status(400).json({ error: "Title, author, and price are required" });
    }
    const book = new Book(req.body);
    await book.save();
    res.status(201).json(book);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ✅ PUT update book
router.put('/:id', async (req, res) => {
  try {
    const book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!book) return res.status(404).json({ error: "Book not found" });
    res.status(200).json(book);
  } catch (err) {
    res.status(400).json({ error: "Invalid ID or data" });
  }
});

// ✅ DELETE book
router.delete('/:id', async (req, res) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) return res.status(404).json({ error: "Book not found" });
    res.status(200).json({ message: "Book deleted successfully" });
  } catch (err) {
    res.status(400).json({ error: "Invalid ID" });
  }
});

module.exports = router;
